import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { HttpClient } from '@angular/common/http';  // ✅ Import HttpClient
import { Router } from '@angular/router';  // ✅ Import Router

@Component({
  selector: 'app-login',
  standalone: true,
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css'],
  imports: [CommonModule, FormsModule]  
})
export class LoginComponent {
  username: string = '';
  password: string = '';
  apiUrl = 'http://localhost:9000/user/login'; // ✅ Backend API

  constructor(private http: HttpClient, private router: Router) {}  // ✅ Inject HttpClient & Router

  login() {
    const userData = { username: this.username, password: this.password };

    this.http.post<{ token: string; role: string }>(this.apiUrl, userData)
      .subscribe({
        next: (response) => {
          console.log('Login Successful', response);
          localStorage.setItem('token', response.token);  // ✅ Save JWT token
          localStorage.setItem('role', response.role);    // ✅ Save User Role
          this.router.navigate(['/']);  // ✅ Redirect to Home
        },
        error: (err) => {
          console.error('Login Failed', err);
          alert('Invalid username or password!');
        }
      });
  }
}
