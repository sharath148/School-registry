import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root',  // ✅ Makes the service available application-wide
})
export class AuthService {
  private apiUrl = 'http://localhost:9000/user/login';
  // 🔹 Replace with your actual API endpoint

  constructor(private http: HttpClient) {}

  // 🔹 Login method - Sends user credentials and receives a JWT token
  login(username: string, password: string): Observable<any> {
    return this.http.post(this.apiUrl, { username, password });
  }

  // 🔹 Store JWT token in localStorage
  setToken(token: string): void {
    localStorage.setItem('authToken', token);
  }

  // 🔹 Retrieve JWT token
  getToken(): string | null {
    return localStorage.getItem('authToken');
  }

  // 🔹 Check if user is authenticated
  isAuthenticated(): boolean {
    return !!this.getToken();
  }

  // 🔹 Logout method - Remove token from storage
  logout(): void {
    localStorage.removeItem('authToken');
  }
}
